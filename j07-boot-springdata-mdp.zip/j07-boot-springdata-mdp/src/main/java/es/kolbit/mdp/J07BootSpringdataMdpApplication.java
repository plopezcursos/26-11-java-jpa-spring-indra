package es.kolbit.mdp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class J07BootSpringdataMdpApplication {

	public static void main(String[] args) {
		SpringApplication.run(J07BootSpringdataMdpApplication.class, args);
	}

}
